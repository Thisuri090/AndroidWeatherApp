package Common;

import android.location.Location;

public class Common {

    public static final String  APP_ID = "a03c704e608b599e78fcc3e60adafe78";
    public static Location current_location=null;

}
