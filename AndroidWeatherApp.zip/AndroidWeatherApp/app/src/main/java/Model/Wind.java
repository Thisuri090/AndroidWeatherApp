package Model;

public class Wind {
    private double speed;
    private double deg;
}
